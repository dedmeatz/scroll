//
//  totalview.swift
//  test
//
//  Created by Karthik Aiyer on 30/9/17.
//  Copyright © 2017 Karthik Aiyer. All rights reserved.
//

import UIKit

class totalview: UIView {
    @IBOutlet weak var stack: UIStackView!
    var view: UIView!

    override init(frame: CGRect) {
        super.init(frame: frame)
        xibSetup()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        xibSetup()
    }

    convenience init(views: [UIView]){
        self.init(frame: (UIApplication.shared.delegate as? AppDelegate)?.window?.frame ?? .zero)
        
        self.stack.distribution = .fill
        self.stack.spacing = 0
        
        for view in views {
            self.stack.addArrangedSubview(view)
        }
        
    }

    func xibSetup() {
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: "totalview", bundle: bundle)
        let view = nib.instantiate(withOwner: self, options: nil)[0] as! UIView
        view.frame = self.bounds

        self.addSubview(view)
    }
    
}
