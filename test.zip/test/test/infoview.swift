//
//  infoview.swift
//  test
//
//  Created by Karthik Aiyer on 30/9/17.
//  Copyright © 2017 Karthik Aiyer. All rights reserved.
//

import UIKit

class infoview: UIView {
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var message: UILabel!
    var view: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        xibSetup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        xibSetup()
    }
    
    convenience init(title: String, message: String){
        self.init(frame: CGRect.zero)
        
        self.title.text = title
        self.message.text = message
        
        self.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([NSLayoutConstraint(item: self, attribute: NSLayoutAttribute.bottom, relatedBy: NSLayoutRelation.equal, toItem: self.message, attribute: NSLayoutAttribute.bottom, multiplier: 1, constant: 0)])
    }
    
    func xibSetup() {
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: "infoview", bundle: bundle)
        let view = nib.instantiate(withOwner: self, options: nil)[0] as! UIView
        view.frame = self.bounds
        
        self.addSubview(view)
    }
}
