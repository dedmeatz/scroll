//
//  imageview.swift
//  test
//
//  Created by Karthik Aiyer on 30/9/17.
//  Copyright © 2017 Karthik Aiyer. All rights reserved.
//

import UIKit

class imageview: UIView {
    @IBOutlet weak var image: UIImageView!
    var view: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        xibSetup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        xibSetup()
    }
    
    convenience init(image: UIImage){
        self.init(frame: CGRect.zero)
        
        self.image.image = image
        
        NSLayoutConstraint.activate([NSLayoutConstraint(item: self, attribute: NSLayoutAttribute.bottom, relatedBy: NSLayoutRelation.equal, toItem: self.image, attribute: NSLayoutAttribute.bottom, multiplier: 1, constant: 0)])
    }
    
    func xibSetup() {
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: "imageview", bundle: bundle)
        let view = nib.instantiate(withOwner: self, options: nil)[0] as! UIView
        view.frame = self.bounds
        
        self.addSubview(view)
    }

}
